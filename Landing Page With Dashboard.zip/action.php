﻿<!DOCTYPE html>
<html lang="en">
	<head>
		<!-- This page created by MAJDI AWAD as a part of full leads management system. check the read me file for more info -->
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
		
		<title>KIC Landing Page System</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">
		<link href="fonts/icomoon/style.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file its on the root if you want to modify it with the name of style.css -->
		<link rel="stylesheet" href="style.css">
		<!-- Loading third party javascript. no need to modify it -->
		<!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->
	</head>
	<body>
		<!-- START THE PHP SECTION IN ORDER TO TRANSFER THE ENTERED DATA TO LEADS TABLE IN KIC DATABASE -->
		<?php
		
		// connect to the DB
		
		$servername = "localhost";
		$username = "root";
		$password = "";
		$database = "kic";

		$conn = new mysqli($servername, $username, $password, $database);

    			if ($conn->connect_error) {
        
        			die("connection failed: " . $conn->connect_error);
    				}

		
		// I used the global variable to save the entered valuses in a variables
		
		$fname   = $_POST['fname'];
		$lname   = $_POST['lname'];
		$email   = $_POST['email'];
		$phone   = $_POST['phone'];
		$gpa     = $_POST['gpa'];
		$campus  = $_POST['campus'];
		$level   = $_POST['level'];
		$program = $_POST['program'];
		$reach   = $_POST['reach'];
		
		// I made my sql query here and I saved it in the variable [sql].
		
		$sql = "INSERT INTO leads (fname, lname, email, phone, gpa, campus, level, program, reach, status) VALUES ('$fname', '$lname', '$email', '$phone', '$gpa', '$campus', '$level', '$program', '$reach', 'Query')";
		
		if ($conn->query($sql) === TRUE) {
  					echo "";
				} else {
  					echo "Error: " . $sql . "<br>" . $conn->error;
				}
		?>
		<!-- END OF THE PHP SECTION -->
		<div class="site-content">
			<div class="container">
				<main class="main-content">
					<div class="content">
						<header class="site-header">
							<!-- Change the logo here. you can find the PNG logo in images folder with the name of logo.png. The logo size is 144px * 120px -->
							<a href="" class="logo"><img src="images/logo.png" alt=""></a>
							<!-- Modify the header title and twx here -->
							<div class="header-type">
								<h1>Thank you for applying</h1>
								<p>Someone from our admission department will contact you soon for more information.</p>
							</div>
						</header> 
						<!-- The end of the header section -->
						<!-- thange the main image (the college image) here, you can find the image in the dummy forlder with the name of banner.jpg and the banner size is 770px * 326px -->
						<div class="banner">
							<img src="dummy/banner2.jpg" alt="Banner">
						</div>
						<!-- Modify the main title and text under the bunner. -->
						<h2>Thank you for applying</h2>
						<p>The following links may be useful for you:</p>

						<!-- Start the links section add, modify, or delete links based on your needs">) -->
								<div class="feature">
								<!-- Modify the the link for KIC website -->
								<p><h1><a href="https://kic.ac.ae/admissions" target="_blank">KIC ADMISSION DEPARTMENT</a></h1></p>
								<p><h1><a href="https://kic.ac.ae/general-education/" target="_blank">GENERAL EDUCATION</a></h1></p>
								<p><h1><a href="https://kic.ac.ae/future-students/" target="_blank">FUTURE STUDENTS</a></h1></p>
								<p><h1><a href="https://kic.ac.ae/current-students/" target="_blank">CURRENT STUDENTS</a></h1></p>
								<p><h1><a href="https://kic.ac.ae/category/campus-news/" target="_blank">CAMPUS NEWS</a></h1></p>
							</div>
						</div>
					</div>
					<!-- End of the links section. -->
				<!-- Start the footer section -->
				<!-- Modify the copyright here. remove my name and right anything you want but remember that I built this so follow me. -->
				<footer class="site-footer">
					<p>Copyright &copy; 2022 Khawarizmi International College. Designed by MAJDI AWAD</p>
					<!-- Modify the the social icon .. add, edit, or delete icons based on your social networks -->
					<div class="social-links">
						<a href="https://www.facebook.com/KIC.UAE/" target="_blank" class="facebook"><i class="fa fa-facebook"></i></a>
						<a href="https://twitter.com/kic_ae" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a>
					</div>
				</footer>
				<!-- End the footer section -->
			</div>
		</div>
		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>
	</body>
</html>