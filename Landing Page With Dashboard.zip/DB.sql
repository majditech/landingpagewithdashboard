-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 12, 2022 at 05:50 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kic`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'kic', 'kic@123');

-- --------------------------------------------------------

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
CREATE TABLE IF NOT EXISTS `leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` text NOT NULL,
  `phone` text NOT NULL,
  `gpa` text NOT NULL,
  `campus` text NOT NULL,
  `level` text NOT NULL,
  `program` text NOT NULL,
  `reach` text NOT NULL,
  `status` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leads`
--

INSERT INTO `leads` (`id`, `fname`, `lname`, `email`, `phone`, `gpa`, `campus`, `level`, `program`, `reach`, `status`) VALUES
(15, 'fadi', '', 'majdi@itisae.com', '0505411578', '95%', 'Abu Dhabi', 'B', 'IT', 'Facebook', 'Query'),
(13, 'ah', '', 'manukaajman@gmail.com', '0505411578', '99%', 'Al Ain', 'A', 'Graphics', 'Instagram', 'Query'),
(14, 'majdi', 'awad', 'majdiawad371@gmail.com', '+971563041393', '93%', 'Abu Dhabi', 'B', 'IT', 'Google', 'Opened File'),
(16, 'neball', '', 'instructor@demo.com', '+971563041393', '80%', 'Abu Dhabi', 'A', 'MC', 'Google', 'Query'),
(17, 'maha', '', 'admin@admin.com', '0505411578', '90%', 'Abu Dhabi', 'B', 'ML', 'Google', 'Query'),
(18, 'maram', '', 'maramawad20@hotmail.com', '0563041393', '95%', 'Al Ain', 'A', 'ML', 'Linkedin', 'registered'),
(19, 'mai', 'ms', 'manukaajman@gmail.com', '0505411578', '95%', 'Al Ain', 'A', 'Graphics', 'Twitter', 'registered'),
(20, 'rami', 'aiash', 'majdiawad371@gmail.com', '0505411578', '95%', 'Abu Dhabi', 'B', 'BA', 'Google', 'Canceled'),
(24, 'rami', 'aiash', 'majdiawad371@gmail.com', '0505411578', '95%', 'Abu Dhabi', 'A', 'SRCEC', 'Friends', 'Query'),
(22, 'rami', 'aiash', 'majdiawad371@gmail.com', '0505411578', '95%', 'Abu Dhabi', 'B', 'SRCEC', 'Alwaseet', 'Opened File'),
(23, 'rami', 'aiash', 'majdiawad371@gmail.com', '0505411578', '95%', 'Abu Dhabi', 'A', 'SRCEC', 'Facebook', 'Query'),
(25, 'majdi', 'M', 'majdiawad371@gmail.com', '0505411578', '95%', 'Abu Dhabi', 'B', 'BA', 'Google', 'Query');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
