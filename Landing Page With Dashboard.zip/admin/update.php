 <?php
// connet to DB
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kic";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
		// I have used the global variable to assign values for the following variables
		$id = $_POST['id'];
		$fname   = $_POST['fname'];
		$lname   = $_POST['lname'];
		$email   = $_POST['email'];
		$phone   = $_POST['phone'];
		$gpa     = $_POST['gpa'];
		$campus  = $_POST['campus'];
		$level   = $_POST['level'];
		$program = $_POST['program'];
		$reach   = $_POST['reach'];
		$status  = $_POST['status'];

// I have used UPDATE SET SQL commands 
$sql = "UPDATE leads SET fname='$fname', lname='$lname', email='$email', phone='$phone', gpa='$gpa', campus='$campus', level='$level', program='$program', reach='$reach', status='$status' WHERE id=$id";
// Just a normal if condition to make sure that the row updated
if ($conn->query($sql) === TRUE) {
  header ('Location: home.php');
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?> 