﻿<?php

// Connect to the DB

$servername = "localhost";
$username = "root";
$password = "";
$database = "kic";

$conn = new mysqli($servername, $username, $password, $database);
	if ($conn->connect_error) {
        	die("connection failed: " . $conn->connect_error);
    				}

// Use the global variables to save the entered values in variables

$username = $_POST['username'];
$password = $_POST['password'];

// normal SELECT sentence

$sql = mysqli_query($conn,"SELECT username, password FROM admins WHERE username='$username' AND password='$password'");

// Check if username and password are correct

if($sql->num_rows > 0) {

	header ('Location: home.php');
	
	} else {
			
		echo "Wrong Username or Password";
		
		}
		
?>