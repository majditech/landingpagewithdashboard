﻿<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>KIC Leads Management System - Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="home.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="search.php"> <i class="menu-icon fa fa-search"></i>Search </a>
                    </li>
					<li>
                        <a href="campus.php"> <i class="menu-icon fa fa-university"></i>Campus Report </a>
                    </li>
					<li>
                        <a href="program.php"> <i class="menu-icon fa fa-university"></i>Programs Report </a>
                    </li>
					<li>
                        <a href="method.php"> <i class="menu-icon fa fa-university"></i>Methods Report </a>
                    </li>
					<li class="active">
                        <a href="status.php"> <i class="menu-icon fa fa-university"></i>Status Report </a>
                    </li>
					<li>
                        <a href="roi.php"> <i class="menu-icon fa fa-university"></i>ROI Report </a>
                    </li>
					<li class="active">
                        <a href="final.php"> <i class="menu-icon fa fa-file"></i>Final Report </a>
                    </li>
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>WELCOME to KLMS</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><a href="index.php">Logout</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Leads status Report</strong>
                            </div>
							<div style="margin:10px; padding:10px;">
							<!-- Reports Generation Form -->
							<p>
								<?php
										// connect to DB
										$servername = "localhost";
										$username = "root";
										$password = "";
										$database = "kic";

										$conn = new mysqli($servername, $username, $password, $database);

											if ($conn->connect_error) {
												
												die("connection failed: " . $conn->connect_error);
											}
											
											// Select all from table leads which is available on kic DB
											$query = $conn->query("SELECT * FROM leads");
											// Query
											$querya = $conn->query("SELECT * FROM leads WHERE status='Query'");
											$queryap = ($querya->num_rows / $query->num_rows) * 100;
											// Potential
											$po = $conn->query("SELECT * FROM leads WHERE status='potential'");
											$pop = ($po->num_rows / $query->num_rows) * 100;	
											// Opened File
											$op = $conn->query("SELECT * FROM leads WHERE status='Opened File'");
											$opp = ($op->num_rows / $query->num_rows) * 100;
											// Registered
											$re = $conn->query("SELECT * FROM leads WHERE status='registered'");
											$rep = ($re->num_rows / $query->num_rows) * 100;	
											// Canceled
											$can = $conn->query("SELECT * FROM leads WHERE status='Canceled'");
											$canp = ($can->num_rows / $query->num_rows) * 100;											
								?>
							
				<!-- QUERY -->
				<div class="col-lg-3 col-md-6">
                <div class="social-box">
                    <i><img src="images/ask.jpg"></i>
                    <ul>
                        <li>
                            <span><b><?php echo $queryap . "% of leads"; ?></b></span>
                            <span></span>
                        </li>
                        <li>
                            <span><b>Number of leads is: </b></span>
                            <span><b><?php echo $querya->num_rows; ?></b></span>
                        </li>
                    </ul>
                </div>
				</div>
				
				<!-- Potential -->
				<div class="col-lg-3 col-md-6">
                <div class="social-box">
                    <i><img src="images/po.jpg"></i>
                    <ul>
                        <li>
                            <span><b><?php echo $pop . "% of leads"; ?></b></span>
                            <span></span>
                        </li>
                        <li>
                            <span><b>Number of leads is: </b></span>
                            <span><b><?php echo $po->num_rows; ?></b></span>
                        </li>
                    </ul>
                </div>
				</div>					

				<!-- Opened File -->
				<div class="col-lg-3 col-md-6">
                <div class="social-box">
                    <i><img src="images/op.jpg"></i>
                    <ul>
                        <li>
                            <span><b><?php echo $opp . "% of leads"; ?></b></span>
                            <span></span>
                        </li>
                        <li>
                            <span><b>Number of leads is: </b></span>
                            <span><b><?php echo $op->num_rows; ?></b></span>
                        </li>
                    </ul>
                </div>
				</div>

				<!-- Registered -->
				<div class="col-lg-3 col-md-6">
                <div class="social-box">
                    <i><img src="images/re.jpg"></i>
                    <ul>
                        <li>
                            <span><b><?php echo $rep . "% of leads"; ?></b></span>
                            <span></span>
                        </li>
                        <li>
                            <span><b>Number of leads is: </b></span>
                            <span><b><?php echo $re->num_rows; ?></b></span>
                        </li>
                    </ul>
                </div>
				</div>				
				</p>
				
				
				<!-- NEW PROGRAMS LINE ------------------------------------------------------------------------ -->
				
						<div class="col-md-12">

							<div style="margin:10px; padding:10px;">
							<!-- Reports Generation Form -->
							<p>
				<!-- CANCELED -->
				<div class="col-lg-3 col-md-6">
                <div class="social-box">
                    <i><img src="images/can.jpg"></i>
                    <ul>
                        <li>
                            <span><b><?php echo $canp . "% of leads"; ?></b></span>
                            <span></span>
                        </li>
                        <li>
                            <span><b>Number of leads is: </b></span>
                            <span><b><?php echo $can->num_rows; ?></b></span>
                        </li>
                    </ul>
                </div>
				</div>
				
				</p>
				
    <!-- Right Panel -->
	
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
