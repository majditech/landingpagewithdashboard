﻿<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>KIC Leads Management System - Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="home.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="search.php"> <i class="menu-icon fa fa-search"></i>Search </a>
                    </li>
					<li>
                        <a href="campus.php"> <i class="menu-icon fa fa-university"></i>Campus Report </a>
                    </li>
					<li>
                        <a href="program.php"> <i class="menu-icon fa fa-university"></i>Programs Report </a>
                    </li>
					<li>
                        <a href="method.php"> <i class="menu-icon fa fa-university"></i>Methods Report </a>
                    </li>
					<li>
                        <a href="status.php"> <i class="menu-icon fa fa-university"></i>Status Report </a>
                    </li>
					<li>
                        <a href="roi.php"> <i class="menu-icon fa fa-university"></i>ROI Report </a>
                    </li>
					<li class="active">
                        <a href="final.php"> <i class="menu-icon fa fa-file"></i>Final Report </a>
                    </li>
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>WELCOME to KLMS</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><a href="index.php">Logout</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">General Report</strong>
                            </div>
							<div style="margin:10px; padding:10px;">
							<?php
							$servername = "localhost";
							$username = "root";
							$password = "";
							$database = "kic";

							$conn = new mysqli($servername, $username, $password, $database);

							if ($conn->connect_error) {
												
							die("connection failed: " . $conn->connect_error);
							}
							
							$total = $conn->query("SELECT * FROM leads");
							$ask = $conn->query("SELECT * FROM leads WHERE status='Query'");
							$open = $conn->query("SELECT * FROM leads WHERE status='Opened File'");
							$reg = $conn->query("SELECT * FROM leads WHERE status='registered'");
							$cancel = $conn->query("SELECT * FROM leads WHERE status='Canceled'");
							$it = $conn->query("SELECT * FROM leads WHERE program='IT'");
							$graphic = $conn->query("SELECT * FROM leads WHERE program='Graphics'");
							$ml = $conn->query("SELECT * FROM leads WHERE program='ML'");
							$hm = $conn->query("SELECT * FROM leads WHERE program='HM'");
							$ba = $conn->query("SELECT * FROM leads WHERE program='BA'");
							$mc = $conn->query("SELECT * FROM leads WHERE program='MC'");
							$sr = $conn->query("SELECT * FROM leads WHERE program='SRCEC'");
							$facebook = $conn->query("SELECT * FROM leads WHERE reach='Facebook'");
							$instagram = $conn->query("SELECT * FROM leads WHERE reach='Instagram'");
							$twitter = $conn->query("SELECT * FROM leads WHERE reach='Twitter'");
							$linkedin = $conn->query("SELECT * FROM leads WHERE reach='Linkedin'");
							$google = $conn->query("SELECT * FROM leads WHERE reach='Google'");
							$alwaseet = $conn->query("SELECT * FROM leads WHERE reach='Alwaseet'");
							$friends = $conn->query("SELECT * FROM leads WHERE reach='Friends'");
							$abudhabi = $conn->query("SELECT * FROM leads WHERE campus='Abu Dhabi'");
							$alain = $conn->query("SELECT * FROM leads WHERE campus='Al Ain'");

							?>
							
							<p>
							<div align="center">
							<img src="images/avatar/logo.png"><br><br>
							<h3>SUMMER 2022 DIGITAL CAMPAIGN</H3>
							</div><br><br>
							<p>
							<b>Dear to whom it my concern,</b><br><br>
							We have got <?php echo $total->num_rows; ?> leads during this campaign as follows:<br><br>
							
							1- <?php echo $abudhabi->num_rows; ?> leads for Abu Dhabi campus.<br>
							2- <?php echo $alain->num_rows; ?> leads for Al Ain campus.<br><br>
							
							We were able to convert <?php echo $reg->num_rows; ?> leads to registered students and <?php echo $open->num_rows; ?> opend new files but they did not register for courses yet. Also, we would like to mention that we have collected your leads via multiple channels as below:<br><br>
							
							1- <?php echo $facebook->num_rows; ?> from FACEBOOK.<br>
							2- <?php echo $instagram->num_rows; ?> from INSTAGRAM.<br>
							3- <?php echo $twitter->num_rows; ?> from TWITTER.<br>
							4- <?php echo $linkedin->num_rows; ?> from LINKEDIN.<br>
							5- <?php echo $google->num_rows; ?> from GOOGLE.<br>
							6- <?php echo $alwaseet->num_rows; ?> from AL WASEET newspapers.<br>
							7- <?php echo $friends->num_rows; ?> by WORD OF MOUTH.<br><br>
							
							We were able to collect <?php echo $it->num_rows; ?> leads for Information Technoloy, <?php echo $graphic->num_rows; ?> leads for Graphic design. <?php echo $ml->num_rows; ?> of the applicants indicated their desire to join Medical Labs program. <?php echo $ml->num_rows; ?> are interested in Health Management program. <?php echo $ba->num_rows; ?> wants to join the Business Administration program. <?php echo $mc->num_rows; ?> expressed their desire to join Mass Communication program and <?php echo $sr->num_rows; ?> applied for the Science in Respiratory Care and Emergency Care.<br><br>
							Finally, we would like to thank all our colleagues and partners in this campaign for all the support they gave us in order to make it a success. We will send a return on investment report to the relevant departments and we will study the results of this campaign in order to develop future campaigns.<br><br>
							Best Regards,<br><br>
							DIGITAL MARKITING DEPARTMENT<br>
							KHAWARIZMI INTERNATIONAL COLLEGE - KIC<br>
							PHONE: +97122015000<br>
							WWW.KIC.AC.AE<br>
							
							</p>
				
    <!-- Right Panel -->
	
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
