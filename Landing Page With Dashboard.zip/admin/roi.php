﻿<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>KIC Leads Management System - Dashboard</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>


    <!-- Left Panel -->

    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="home.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="search.php"> <i class="menu-icon fa fa-search"></i>Search </a>
                    </li>
					<li>
                        <a href="campus.php"> <i class="menu-icon fa fa-university"></i>Campus Report </a>
                    </li>
					<li>
                        <a href="program.php"> <i class="menu-icon fa fa-university"></i>Programs Report </a>
                    </li>
					<li>
                        <a href="method.php"> <i class="menu-icon fa fa-university"></i>Methods Report </a>
                    </li>
					<li>
                        <a href="status.php"> <i class="menu-icon fa fa-university"></i>Status Report </a>
                    </li>
					<li class="active">
                        <a href="roi.php"> <i class="menu-icon fa fa-university"></i>ROI Report </a>
                    </li>
					<li class="active">
                        <a href="final.php"> <i class="menu-icon fa fa-file"></i>Final Report </a>
                    </li>
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>WELCOME to KLMS</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active"><a href="index.php">Logout</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
		
		<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Return Of Investment</strong>
                            </div>
							<div style="margin:10px; padding:10px;">
							<!-- Reports Generation Form -->
							<p>
							In order to calculate the ROI, we are going to do the following:<br><br>
							1- We will expect the registered student to pay ten thousand dirhams only in his first semester.<br>
							2- We will multiply the number of the registered students in AED 10000 and we will call it income.<br>
							3- We will subtract the campaign cost from the income. The result will be the profit.<br>
							4- Then we will divide the profit by the campaign cost.<br>
							5- The result of the previous point will be multiplied by 100 in order to get the percentage.<br><br>
							
							<h2> Kindly enter the campaign cost </h2><br>
							<form action="#" method="get">
							<input style="width:350px; height:50px; font-family:'Century Gothic';" type="text" name="cost" placeholder="Campaign Cost ..."><br><br>
							<input name="cal" style="width:350px; height:50px; border:thin; font-family:'Century Gothic'; background-color:#99b433; border:thin;" type="submit" value="CALCULATE">
							</form>
							<?php
							
							$servername = "localhost";
							$username = "root";
							$password = "";
							$database = "kic";

							$conn = new mysqli($servername, $username, $password, $database);

							if ($conn->connect_error) {
												
							die("connection failed: " . $conn->connect_error);
							}
							if(isset($_GET['cal'])) {
							$cost = $_GET['cost'];
							$rs = $conn->query("SELECT * FROM leads WHERE status='registered'");
							$income = $rs->num_rows * 10000;
							$profit = $income - $cost;
							$per = $profit / $cost;
							$roi = $per * 100;
							
							echo $per . " %";
							}
							?>
							</p>
				
    <!-- Right Panel -->
	
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script src="vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/widgets.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });
        })(jQuery);
    </script>

</body>

</html>
